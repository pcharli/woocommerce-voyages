# Produits

# Bagages

## Sacoche discrète
- 19€
- Marre d’avoir les poches pleines en voyage ?
	- VOS DOCUMENTS LES PLUS PRECIEUX, TOUJOURS SUR VOUS. Ses 5 compartiments vous permettent de loger vos effets, et ceux de vos compagnons de voyages, en un clin d’œil.

	- EN SECURITE, OU QUE VOS PAS VOUS MENENT. Difficilement détectable sous les vêtements, votre pochette voyage noire, sobre et polyvalente, protège également vos documents contre le vol de données RFID.

	- PENSEE POUR UN USAGE NOMADE. Côté pile, un filet doux et respirant pour maximiser le confort sur la peau. Côté face, le nylon 300D indéchirable et étanche protège vos documents de l’usure et des chocs.
- images : sac1
- extrait : VOYAGEZ ZEN. Très discrète sous les vêtements, la pochette tour de cou Nomalite est munie de bandoulières extra-résistantes. Sa technologie anti-RFID protège son contenu du vol de données sans contact que peuvent subir cartes bleues et passeports biométriques.
- keys : valise

## Trolley
- 86 €
- Valise de cabine conforme aux règlements aériens
	- Compartiment double à fermeture éclair pour garder vos affaires en sécurité
	- Hauteur : 51 cm, Largeur : 32,5 cm, Profondeur : 24 cm
	- Fabriqué dans un mélange 60% nylon 40% polyester
	- Des sangles de compression et de fixation pour garantir un maintien idéal pendant le transport

- images : trolley
- extrait : Votre fidèle compagnon de voyage taille cabine en version Black Denim : emportez tout ce dont vous avez besoin puis rangez-le à plat une fois arrivé à destination
- keys : valise

## ESSENTIAL LITE
- 400 €
- Raffiné dans les moindres détails
	- La valise la plus légère de RIMOWA
	- Stabilité optimale
	- Portabilité ultime sans compromettre la durabilité
	- Verrous approuvés TSA
- images : trolley-luxe
- extrait : Trolley à roulette avec serviette porte-ordinateur amovible et compartiments business détachable.
- keys : valise

## Trousse suspendue
- 21,97 €
- Piable et à suspendre
	- Le crochet en acier inoxydable vous permet d'accrocher la trousse sur la porte de la salle de bain, à la barre de la douche ou sur le porte serviettes pour un accès facile. Plus besoin de défaire toutes vos affaires ou de fouiller dans vos bagages.
	- Grâce aux nombreux compartiments de cette fantastique trousse de toilette, vous allez trouver tout de suite ce que vous cherchez, sans avoir à fouiller dans le bazar des objets personnels et des accessoires jetés aux hasard.
	- Celle-ci a beaucoup d'espace de rangement pour tous vos cosmétiques, votre maquillage, vos accessoires de rasage, votre brosse à dent et dentifrice, vos produits d'hygiène féminine etc. 
	- En polyester 300D de qualité supérieure et doublé en PVC. 
- images : trousse
- extrait : Idéale pour organiser et suspendre ses articles de toilette. Ainsi, ils ne prennent jamais l'eau et sont compartimentés !
- keys : trousse

# Accessoires

## Adaptateur de Voyage Universel
- 16,50 €
- Connectez tous vos appareils partout dans le monde
	- Adaptateur international de prise - Adaptateur international de prise électrique (UK / US / AUS / EU Plug) travaille dans plus de 150 pays, états-Unis, Canada, Europe, Royaume-Uni, Chine, France, Allemagne, Royaume-Uni, l'Espagne, l'Union européenne, la Grande-Bretagne, Irlande, Hong Kong, Singapour, Fidji, la Chine, le Japon, l'Australie, la Nouvelle-Zélande, etc. (Sauf l'Afrique.) (Attention! Cet adaptateur ne convertit pas la tension et courant de sortie de puissance!)
	- 4 ports USB - Cet adaptateur universel dispose de 4 ports USB (de type A). La tension d'entrée est de 100-240 V AC, ce qui signifie que vous pouvez l'utiliser partout dans le monde pour charger vos appareils USB simultanément, par exemple : votre téléphone portable, iPhone, iPad, Power Bank, MP3 /4/5 et appareil photo, etc.
	- Certification de sécurité - Réglementations FCC et CE. Puissance nominale (6 A max) : 660 W max à 110V AC, 1380 W max à 230 V AC). Veuillez lire attentivement l'introduction et la description du produit avant de l'utiliser.
- images : adaptateur
- extrait : Tout-en-Un Multi-Nations
- keys : électronique

## Batterie externe
- 42 €
- Flexibilité inégaliée
	- 20% plus petit et plus léger que précédent. La taille: 152 × 74 × 23mm ; le poids: 380g
	- Double entrée, le Micro USB et le Type-C charge pour se recharger de mort à 80% en seulement 3 heures, 2,5 fois plus vite que les chargeurs portables normaux.
	- Chargez simultanément 4 appareils, Le port vert caractérisé par la technologie Charge Rapide (QC2.0, QC3.0, FCP et plus).
	- Les deux ports de type C supportent, La technologie unidirectionnelle de type C empêche la batterie externe de voler la puissance d'origine de l'appareil en charge.
	- Evite efficacement la surcharge, la surintensité et le court-circuit de vos appareils, et conforme aux spécifications CE, RoHS et FCC.
- images : battery
- extrait : Charge Rapide en USB-C pour iPhone Samsung Nintendo Switch MacBook et Plus
- keys : électronique

## Coussin écharpe
- 24,99 €
- Oreiller de Voyage Ultra Doux
	- Soutien du cou pendant un vol de longue durée, scientifiquement prouvé
	- Maintient le cou dans une position ergonomique pendant le vol
	- Plus efficace que les oreillers de voyage traditionnels en mousse en forme de U
	- Deux fois moins gros qu’un oreiller de voyage et il pèse seulement 148 grammes – Prend peu de place
	- S'attache facilement aux bagages
- images : echarpe
- extrait : Oreiller de Voyage Ultra Doux offrant Un Soutien de Cou scientifiquement prouvé
- keys : déplacement


## KIT DE SECOURS
- 19,99 €
- 90 articles
	- Trousse de Premiers Secours Composée de 90 Articles avec Packs de Froid Instantané, Sérum Physiologique et Couverture de Survie Isothermique
	- Compacte et idéale pour la maison, au bureau, en voiture, en caravane ou en voyage.
	- Trousse très résistante et durable, en nylon
	- Tous les articles sont conformes aux normes européennes (marquage CE)
- images : secours
- extrait : Vital en randonnée pour réagir en cas de blessures. Le minimum et l'indispensable dans un kit complet.
- keys : trousse

## MINI CADENAS TSA
- 10,90 €
- Diyife cadenas de sécurité à 3 chiffres
	- Les serrures sont TSA (Transportation Security Administration) et Travel Sentry Approved. Si les agents de sécurité du transport veulent accéder à votre sac, ils peuvent utiliser leur clé spéciale pour ouvrir le verrou et ils le verrouilleront à nouveau quand ils auront terminé.
	- Alliage de zinc haute résistance et le câble est fabriqué en acier résistant aux coupures. La seule façon d'ouvrir le verrou est avec la clé spéciale TSA ou en connaissant la combinaison.
	- La combinaison de 3 chiffres est facile à configurer et signifie que vous n'avez pas à vous soucier de garder une clé.
	- Utilisable internationalement sur une grande variété d'articles en plus des bagages ou des valises.
- images : cadenas
- extrait : Des cadenas pour repousser les personnes malintentionnées, avec un système TSA qui permet de passer les douanes US sans soucis !
- keys : déplacement

## MINI CAMERA GO PRO
- 183 €
- GoPro Hero (2018) - Caméra d'action étanche - noir
	- Écran tactile 2 pouce
	- Étanche et résistante
	- Contrôle vocal
	- Wi-Fi et Bluetooth
	- Caméra HERO, Le Cadre, Batterie rechargeable, Fixation adhésive incurvée, Fixation adhésive, Boucle de fixation, Câble USB-C
- images : camera
- extrait : Minuscule caméra HD, indispensable à tout voyageur
- keys : électronique

## DRONE DE VOYAGE FACILE
- 347 €
- Quadricoptère avec Caméra
	- FACILE À VOLER: Le DJI Spark est facile à voler grâce aux technologies de signature de DJI. Vous pourrez faire voler le drone jusqu'à 16 minutes à la fois avec une batterie complètement chargée.
	- CAMÉRA HAUTE PERFORMANCE: Le DJI Spark dispose d'une caméra haute performance qui vous permet de prendre des photos et vidéos en haute qualité grâce à la nacelle mécanique 2-axes.
	- MODES DE VOL INTELLIGENTS: Le DJI Spark possède des modes de vol adroit, fiable et intuitif qui vous permettent de prendre des photos et des vidéos exactement comme vous le souhaitez.
	- TRANSMISSION VIDÉO WI-FI HD: Le drone DJI Spark est livré avec une radiocommande qui permet une transmission vidéo 720p en temps réel à une distance allant jusqu'à 2 km (1,2 mi).
- images : drone
- extrait : Prenez des photos en voyage et offrez-les en direct ! Un format mini, une qualité maxi
- keys : électronique

## LEATHERMAN 19 EN 1
- 36,50 €
- Boîte Pince multifonction avec étui en cuir
	- Pince multifonction 19 outils
	- Couleur argent
	- Etui en cuir
	- 272 grammes
- images : tools
- extrait : Le Leatherman est une boite à outils de poche qui pourrait vous sauver de nombreuses situations !
- keys : tools

## BOUTEILLE PLIABLE
- 15,35 €
- Bouteille d'eau de 1000 ml pliable
	- Nous vous suggérons de le rincer plusieurs fois et de le tremper dans du bicarbonate de soude pendant plusieurs jours avant de l'utiliser
	- 100% Sans BPA & Non Toxic
	- Avec infuseur de qualité supérieure
	- La gourde pliable est facile à réserver et à transporter. Elle économise l'espace après l'enroulement
- images : gourde
- extrait : Une fois pliées, elles font 1/5 de la taille d'origine ! Résistante, elle accepte les températures allant de -20 à +120 °.
- keys : tools

## Des ports USB pour allume-cigare
- 17,99 €
- Transmetteur FM Bluetooth avec 2 ports USB
	- Équipé de 2 USB ports (5V/2.4A & 1A), vous pouvez charger deux appareils simultanément.
	- Avec la technologie de suppression de bruit CVC, vous pouvez profiter d'une qualité sonore full duplex
	- Appels Mains Libres & Diffusion de Navigation
	- Le transmetteur FM affichera le voltage de la voiture quand il est branché à l’allume-cigare.
- images : charge-auto
- extrait : Brancher à votre allume cigare votre téléphone ou autre élément électronique.
- keys : électronique

## Support ventouse pour smartphone
- 47 €
- Support Passif pour smartphone
	- Type d'appareil mobile: Mobile/smartphone
	- Usage adapté: Voiture. Largeur: 8,25 cm
	- Profondeur: 2,22 cm
	- Haut-parleurs intégrés
- images : support-gsm
- extrait : Ce support vous permettra une utilisation sécurisée du GPS et des appels / messages.
- keys : électronique


# Assurances

## AVA TOURIST CARD
- à partir de 70 € / famille
- C’est l’assurance Multirisque
	- Durée de la garantie : Jusqu'à 60 j
	- Court Séjour, loisir
	- Résidence : Union européenne
	- Destination : le Monde
- images : assurance-1
- extrait : L'assurance qui répond à tous les imprévus du voyageur en solitaire, accompagné ou en famille, même en cas d’empêchement de dernière minute avant le départ.
- url : https://www.ava.fr/assurance-voyage/ava-tourist-card/

## Assurance Vacances
- à partir de 45 € / personne
- C’est l’assurance Multirisque
	- Durée de la garantie : Jusqu'à 60 j
	- Court Séjour à titre privé
	- Résidence : France
	- Destination : le Monde
	- Couverture des frais médicaux à l'étranger jusqu'à 300 000€
- images : assurance-2
- extrait : L'assurance multirisque voyage qui couvre tous vos séjours, en France comme à l'étranger, d'une durée de moins de 2 mois.
- url : https://www.allianz-voyage.fr/assurances/vacances/

# Livres

## Le dictionnaire tout en images pour le voyage
- 15 €
- Fini les problèmes de communication
	- Pointez tout simplement l’objet ou le lieu recherché et montrez-le à votre interlocuteur… Vous verrez, il comprendra ! 
	- Ce guide malin, vous aidera à trouver tous les mots qui sauvent.
	- 200 illustrations universelles en couleur ;  5 grands thèmes : transports, informations pratiques, hébergement, restauration et alimentation, culture et loisirs.
	- 5 images bonus consacrées à la séduction
- images : guide-langue
- extrait : G'Palémo Reliure à spirales
- url : https://www.amazon.fr/GPalemo-Collectif/dp/2012445314
- keys : dictionnaire

## L'essentiel de Barcelonne
- 15 €
- - Barcelonne
	- 23 pages
	- 5 catégories : restaurants, ars, hôtels, à voir, conseils
- fichier : partirdemain-barcelone-essentiel-2019.pdf
- extrait : Partir demain à Barcelonne
- keys : guide

## L'essentiel de Venise
- 18 €
- - Venise
	- 26 pages
	- 5 catégories : restaurants, ars, hôtels, à voir, conseils
- fichier : partirdemain-venise-essentiel-2019.pdf
- extrait : Partir demain à Venise
- keys : guide

## L'essentiel de Londres
- 15 €
- - Londres
	- 23 pages
	- 5 catégories : restaurants, ars, hôtels, à voir, conseils
- fichier : partirdemain-londres-essentiel-2019.pdf
- extrait : Partir demain à Londres
- keys : guide